function onSubmitCustomProduct() {
  if (document.getElementById("custom-product-form").valid()) {
    document.getElementById("custom-product-form").submit();
  }
}
